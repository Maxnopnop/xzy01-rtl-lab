module request_delay (
    input  clk,
    input  rst_n,
    input  din,
    output q
);

    reg [1:0] state;
    localparam IDLE     = 2'b00;
    localparam RESPONSE = 2'b01;
    localparam COOLDOWN = 2'b10;

    assign q = (state == RESPONSE);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
        end else begin
            case (state)
                IDLE: begin
                    if (din)
                        state <= RESPONSE;
                    else
                        state <= IDLE;
                end
                RESPONSE: begin
                    state <= COOLDOWN;
                end
                COOLDOWN: begin
                    if (din)
                        state <= COOLDOWN;
                    else
                        state <= IDLE;
                end
                default: begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
