module debounce3 (
    input  clk,
    input  rst_n,
    input  din,
    output q
);

    localparam [2:0] S0 = 3'd0;
    localparam [2:0] S1 = 3'd1;
    localparam [2:0] S2 = 3'd2;
    localparam [2:0] S3 = 3'd3;
    localparam [2:0] S4 = 3'd4;

    reg [2:0] state;
    reg [2:0] next_state;

    assign q = (state == S3) || (state == S4);

    always @(*) begin
        case (state)
            S0: begin
                if (din)
                    next_state = S1;
                else
                    next_state = S0;
            end
            S1: begin
                if (din)
                    next_state = S2;
                else
                    next_state = S0;
            end
            S2: begin
                if (din)
                    next_state = S3;
                else
                    next_state = S0;
            end
            S3: begin
                if (din)
                    next_state = S3;
                else
                    next_state = S4;
            end
            S4: begin
                if (din)
                    next_state = S3;
                else
                    next_state = S0;
            end
            default: begin
                next_state = S0;
            end
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            state <= S0;
        else
            state <= next_state;
    end

endmodule
