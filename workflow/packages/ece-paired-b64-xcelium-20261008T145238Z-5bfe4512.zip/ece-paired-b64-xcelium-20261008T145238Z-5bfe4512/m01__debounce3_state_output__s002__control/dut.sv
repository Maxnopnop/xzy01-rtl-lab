module debounce3(
    input  clk,
    input  rst_n,
    input  din,
    output reg q
);

    localparam [2:0] S_LOW0  = 3'd0;
    localparam [2:0] S_LOW1  = 3'd1;
    localparam [2:0] S_LOW2  = 3'd2;
    localparam [2:0] S_HIGH0 = 3'd3;
    localparam [2:0] S_HIGH1 = 3'd4;

    reg [2:0] state;
    reg [2:0] next_state;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            state <= S_LOW0;
        else
            state <= next_state;
    end

    always @(*) begin
        next_state = state;
        case (state)
            S_LOW0: begin
                if (din)
                    next_state = S_LOW1;
                else
                    next_state = S_LOW0;
            end
            S_LOW1: begin
                if (din)
                    next_state = S_LOW2;
                else
                    next_state = S_LOW0;
            end
            S_LOW2: begin
                if (din)
                    next_state = S_HIGH0;
                else
                    next_state = S_LOW0;
            end
            S_HIGH0: begin
                if (din)
                    next_state = S_HIGH0;
                else
                    next_state = S_HIGH1;
            end
            S_HIGH1: begin
                if (din)
                    next_state = S_HIGH0;
                else
                    next_state = S_LOW0;
            end
            default: next_state = S_LOW0;
        endcase
    end

    always @(*) begin
        case (state)
            S_HIGH0, S_HIGH1: q = 1'b1;
            default:          q = 1'b0;
        endcase
    end

endmodule
