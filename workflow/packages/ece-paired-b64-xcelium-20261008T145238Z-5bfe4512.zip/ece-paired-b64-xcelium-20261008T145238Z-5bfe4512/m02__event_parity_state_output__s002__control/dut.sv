module event_parity (
    input  clk,
    input  rst_n,
    input  din,
    output reg q
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            q <= 1'b0;
        else if (din)
            q <= ~q;
        else
            q <= q;
    end

endmodule
