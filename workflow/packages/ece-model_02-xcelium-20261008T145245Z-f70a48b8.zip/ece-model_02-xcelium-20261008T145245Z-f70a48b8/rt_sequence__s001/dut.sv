module sequence_detector (
    input  logic clk,
    input  logic rst_n,
    input  logic data_in,
    output logic sequence_detected
);

    typedef enum logic [2:0] {
        IDLE,
        S1,
        S2,
        S3,
        S4
    } state_t;

    state_t state, next_state;

    always_comb begin
        next_state = state;

        case (state)
            IDLE: begin
                if (data_in)
                    next_state = S1;
            end

            S1: begin
                if (data_in)
                    next_state = S1;
                else
                    next_state = S2;
            end

            S2: begin
                if (data_in)
                    next_state = S3;
                else
                    next_state = IDLE;
            end

            S3: begin
                if (data_in)
                    next_state = S4;
                else
                    next_state = S2;
            end

            S4: begin
                if (data_in)
                    next_state = S1;
                else
                    next_state = S2;
            end

            default: next_state = IDLE;
        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            state <= IDLE;
        else
            state <= next_state;
    end

    always_comb begin
        sequence_detected = (state == S4);
    end

endmodule
