module framed_parity(input clk, input rst_n, input din, output q);
reg [4:0] state;
always @(posedge clk or negedge rst_n) begin
if(rst_n==1'b0) state <= 0;
else case(state)
0: state <= din ? 2 : 1;
1: state <= din ? 4 : 3;
2: state <= din ? 3 : 4;
3: state <= din ? 6 : 5;
4: state <= din ? 5 : 6;
5: state <= din ? 8 : 7;
6: state <= din ? 7 : 8;
7: state <= din ? 2 : 1;
8: state <= din ? 2 : 1;
default: state <= 0;
endcase
end
assign q = (state==7);
endmodule
