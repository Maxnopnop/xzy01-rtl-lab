module TopModule (
  input [254:0] in,
  output reg [7:0] out
);

  always_comb  begin
    out = 0;
    for (int i=0;i<254;i++)
      out = out + in[i];
  end

endmodule
