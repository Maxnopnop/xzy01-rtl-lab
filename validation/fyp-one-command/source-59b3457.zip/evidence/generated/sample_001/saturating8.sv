module saturating8(
    input  wire [7:0] a,
    input  wire [7:0] b,
    output wire [7:0] y
);
    wire [8:0] sum;

    assign sum = {1'b0, a} + {1'b0, b};
    assign y = sum[8] ? 8'hFF : sum[7:0];
endmodule
