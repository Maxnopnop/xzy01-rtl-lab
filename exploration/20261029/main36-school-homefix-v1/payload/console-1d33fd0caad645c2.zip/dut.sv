module TopModule (
  input              mode,
  input              too_cold,
  input              too_hot,
  input              fan_on,
  output logic       heater,
  output logic       aircon,
  output logic       fan
);
  always_comb begin
    heater = 0;
    aircon = 0;
    fan = fan_on;

    if (mode) begin // Heating mode
      if (too_cold) begin
        heater = 1;
      end
    end else begin // Cooling mode
      if (too_hot) begin
        aircon = 1;
      end
    end
  end
endmodule
