module TopModule (
  input [7:0] a,
  input [7:0] b,
  input [7:0] c,
  input [7:0] d,
  output logic [7:0] min
);
  always_comb begin
    min = a; // Start with the value of a
    if (b < min) min = b; // Compare with b
    if (c < min) min = c; // Compare with c
    if (d < min) min = d; // Compare with d
  end
endmodule
