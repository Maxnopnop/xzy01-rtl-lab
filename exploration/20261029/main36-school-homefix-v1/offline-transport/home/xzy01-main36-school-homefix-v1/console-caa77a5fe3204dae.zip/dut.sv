module TopModule (
    input  logic         clk,
    input  logic         load,
    input  logic [511:0] data,
    output logic [511:0] q
);

    logic [511:0] next_q;
    integer i;

    always_comb begin
        next_q = '0;
        for (i = 0; i < 512; i = i + 1) begin
            next_q[i] = ((i < 511) ? q[i + 1] : 1'b0) &
                        ~q[i] |
                        (q[i] ^ ((i > 0) ? q[i - 1] : 1'b0));
        end
    end

    always_ff @(posedge clk) begin
        if (load)
            q <= data;
        else
            q <= next_q;
    end

endmodule
