"""Independent diagnostic only. Serial, one attempt, no model/network API."""
import hashlib,json,os,re,shutil,signal,stat,subprocess,sys,time,traceback,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STATE=Path.home().resolve()/'xzy01-sampling-school34-v2'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.flush();os.fsync(f.fileno())
def verify():
 for n,h in read(ROOT/'package-lock.json').items():
  if sha(ROOT/n)!=h:raise ValueError('PACKAGE_CHANGED '+n)
 jobs=read(ROOT/'jobs.json');assert len(jobs)==34
 return jobs
def check(jobs):
 errors=[]
 if os.name!='posix':errors.append('Linux required')
 if not shutil.which('tcsh'):errors.append('tcsh missing')
 for p in set(j['setup_script'] for j in jobs):
  if not os.access(p,os.R_OK):errors.append('UNREADABLE '+p)
 if shutil.disk_usage(str(Path.home())).free<2*1024**3:errors.append('Need 2 GiB free HOME')
 print(json.dumps({'ready':not errors,'errors':errors,'jobs':34,'concurrency':1,'retries':0,'model_calls':0,'eda_calls':0}),flush=True)
 return not errors
def process(work):
 start=time.monotonic();limit=None
 with (work/'launcher.log').open('xb') as log:
  p=subprocess.Popen(['tcsh','-f','run.csh'],cwd=str(work),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   while p.poll() is None:
    total=0
    for base,dirs,files in os.walk(str(work)):
     for n in files:
      q=Path(base)/n
      try:s=q.lstat()
      except FileNotFoundError:continue
      if stat.S_ISREG(s.st_mode):
       total+=s.st_size
       if q.suffix=='.log' and s.st_size>32*1024**2:limit='RESOURCE_LIMIT'
    if total>256*1024**2:limit='RESOURCE_LIMIT'
    if time.monotonic()-start>600:limit='TIMEOUT'
    if limit:break
    time.sleep(.25)
  finally:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 return {'returncode':p.returncode,'limit':limit,'seconds':time.monotonic()-start}
def classify(job,work,execution):
 text=(work/'launcher.log').read_text(errors='replace')
 if execution['limit']:return {'status':execution['limit'],'stop':True}
 if re.search(r'license checkout failed|no valid license|licensing error|FLEXnet Licensing error|license.*denied',text,re.I):return {'status':'LICENSE_ERROR','stop':True}
 if execution['returncode']!=0:return {'status':'TOOL_ERROR','stop':True}
 if re.search(r'SORRY|TIMEOUT|\*E,|\*F,|Error-\[',text):return {'status':'DIAGNOSTIC_ERROR','stop':True}
 receipts=re.findall(r'^Mismatches: (\d+) in (\d+) samples\s*$',text,re.M)
 if job['case']['kind']=='synthetic':
  ok=all(len(re.findall(r'^'+p+r' t=\d+ count=\d+\s*$',text,re.M))==1 for p in ('MICRO_PARENT_FINAL','MICRO_CHILD_FINAL'))
 else:ok=len(receipts)==1
 if job['case']['variant']=='observed-r2':ok=ok and 'CAL_FINAL' in text and 'CAL_VALUES' in text
 if not ok:return {'status':'RECEIPT_ERROR','stop':True}
 if job['case']['kind']=='synthetic_negative' and receipts!=[('8','8')]:return {'status':'NEGATIVE_CONTROL_FAILED','stop':True,'receipts':receipts}
 return {'status':'DIAGNOSTIC_RECORDED','stop':False,'receipts':receipts,'trace':[s for s in text.splitlines() if s.startswith(('MICRO_','CAL_','Simulation finished'))]}
def run(jobs):
 if STATE.exists():raise ValueError('STATE_EXISTS: no automatic resume or retry')
 STATE.mkdir();(STATE/'jobs').mkdir();save(STATE/'reservation.json',{'jobs':34,'package_lock':sha(ROOT/'package-lock.json')})
 results=[]
 for job in jobs:
  w=STATE/'jobs'/job['id'];w.mkdir();save(w/'reservation.json',job)
  try:
   for n,h in job['case']['hashes'].items():
    src=ROOT/'specimens'/job['case']['id']/n
    if sha(src)!=h:raise ValueError('INPUT_CHANGED')
    shutil.copyfile(str(src),str(w/n))
   shutil.copyfile(str(ROOT/'scripts'/(job['id']+'.csh')),str(w/'run.csh'))
   shutil.copyfile(str(ROOT/'run.tcl'),str(w/'run.tcl'))
   execution=process(w);result=classify(job,w,execution);result['execution']=execution
   for n,h in job['case']['hashes'].items():
    if sha(w/n)!=h:raise ValueError('INPUT_CHANGED_AFTER')
  except BaseException as exc:
   result={'status':'INTERRUPTED' if isinstance(exc,KeyboardInterrupt) else 'ENVIRONMENT_ERROR','stop':True,'traceback':traceback.format_exc()}
  result.update({'id':job['id'],'tool':job['tool'],'case':job['case']['id']});save(w/'result.json',result);results.append(result)
  print(json.dumps({k:result[k] for k in ('id','tool','case','status','stop')}),flush=True)
  if result['stop']:save(STATE/'STOP.json',result);break
 save(STATE/'summary.json',{'completed':len(results),'total':34,'complete':len(results)==34 and not results[-1]['stop'],'results':results,'model_calls':0,'production_scores_modified':False})
 return 2 if results[-1]['stop'] else 0
def export():
 if not STATE.exists():raise ValueError('NO_STATE')
 dest=STATE/'exports';dest.mkdir(exist_ok=True)
 out=dest/time.strftime('%Y%m%dT%H%M%S');out.mkdir()
 files=[]
 for p in STATE.rglob('*'):
  if 'exports' in p.relative_to(STATE).parts or p.is_symlink() or not p.is_file():continue
  if p.suffix in ('.json','.log','.sv','.v','.csh','.tcl','.txt','.vcd'):files.append(p)
 hashes={p.relative_to(STATE).as_posix():sha(p) for p in files}
 with zipfile.ZipFile(str(out/'results.zip'),'x',zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(str(p),p.relative_to(STATE).as_posix())
 save(out/'index.json',{'sha256':sha(out/'results.zip'),'files':hashes,'package_lock':sha(ROOT/'package-lock.json')})
 shared=Path.home()/'tsclient/FYP'
 if not shared.is_dir():raise ValueError('SHARE_MISSING; local export '+str(out))
 target=shared/'sampling-school34-v2'/out.name;target.mkdir(parents=True,exist_ok=False)
 for p in out.iterdir():
  q=target/p.name
  with p.open('rb') as src,q.open('xb') as dst:shutil.copyfileobj(src,dst);dst.flush();os.fsync(dst.fileno())
  if sha(q)!=sha(p):raise ValueError('SHARED_HASH_MISMATCH '+str(q))
 print('SHARED_COPY_HASH_VERIFIED '+str(target),flush=True)
def main():
 jobs=verify();action=sys.argv[1] if len(sys.argv)>1 else 'check'
 if action=='check':return 0 if check(jobs) else 2
 if action=='export':export();return 0
 if action!='run':raise ValueError('Unknown action')
 if not check(jobs):return 2
 rc=run(jobs);export();return rc
if __name__=='__main__':sys.exit(main())
