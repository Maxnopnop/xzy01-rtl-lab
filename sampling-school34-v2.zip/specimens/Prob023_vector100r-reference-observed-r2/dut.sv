module TopModule (
  input [99:0] in,
  output reg [99:0] out
);
  RefModule reference_alias(.*);
endmodule
