module TopModule (
  input [2:0] vec,
  output [2:0] outv,
  output o2,
  output o1,
  output o0
);
  RefModule reference_alias(.*);
endmodule
