`timescale 1ps/1ps
module child(input clk);
integer edges=0;
always @(posedge clk or negedge clk) begin  begin edges++; $display("MICRO_PORT t=%0t clk=%b n=%0d",$time,clk,edges); end end
initial #32 $finish;
final $display("MICRO_CHILD_FINAL t=%0t count=%0d",$time,edges);
endmodule
module tb;
reg clk; initial begin #1 clk=0; forever #5 clk=~clk; end
integer edges=0;
child u(clk);
always @(posedge clk or negedge clk) begin  begin edges++; $display("MICRO_PARENT t=%0t clk=%b n=%0d",$time,clk,edges); end end
final $display("MICRO_PARENT_FINAL t=%0t count=%0d",$time,edges);
endmodule
