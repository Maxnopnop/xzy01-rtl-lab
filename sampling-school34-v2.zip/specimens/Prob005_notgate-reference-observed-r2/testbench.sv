`timescale 1 ps/1 ps
`define OK 12
`define INCORRECT 13


module stimulus_gen (
	input clk,
	output reg in,
	output reg[511:0] wavedrom_title,
	output reg wavedrom_enable
);


// Add two ports to module stimulus_gen:
//    output [511:0] wavedrom_title
//    output reg wavedrom_enable

	task wavedrom_start(input[511:0] title = "");
	endtask
	
	task wavedrom_stop;
		#1;
	endtask	



	initial begin
		in <= 1'b0;
		wavedrom_start("Inversion");
		repeat(20) @(posedge clk)
			in <= $random;		
		wavedrom_stop();
		
		repeat(200) @(posedge clk, negedge clk)
			in <= $random;
			
		#1 $finish;
	end
	
endmodule

module tb();

	typedef struct packed {
		int errors;
		int errortime;
		int errors_out;
		int errortime_out;

		int clocks;
	} stats;
	
	stats stats1;
	
	
	wire[511:0] wavedrom_title;
	wire wavedrom_enable;
	int wavedrom_hide_after_time;
	
	reg clk=0;
	initial forever
		#5 clk = ~clk;

	logic in;
	logic out_ref;
	logic out_dut;

	initial begin 
		$dumpfile("wave.vcd");
		$dumpvars(1, stim1.clk, tb_mismatch ,in,out_ref,out_dut );
	end


	wire tb_match;		// Verification
	wire tb_mismatch = ~tb_match;
	
	stimulus_gen stim1 (
		.clk,
		.* ,
		.in );
	RefModule good1 (
		.in,
		.out(out_ref) );
		
	TopModule top_module1 (
		.in,
		.out(out_dut) );

	
	bit strobe = 0;
	task wait_for_end_of_timestep;
		repeat(5) begin
			strobe <= !strobe;  // Try to delay until the very end of the time step.
			@(strobe);
		end
	endtask	

	
	final begin
		if (stats1.errors_out) $display("Hint: Output '%s' has %0d mismatches. First mismatch occurred at time %0d.", "out", stats1.errors_out, stats1.errortime_out);
		else $display("Hint: Output '%s' has no mismatches.", "out");

		$display("Hint: Total mismatched samples is %1d out of %1d samples\n", stats1.errors, stats1.clocks);
		$display("Simulation finished at %0d ps", $time);
		$display("Mismatches: %1d in %1d samples", stats1.errors, stats1.clocks);
	end
	
	// Verification: XORs on the right makes any X in good_vector match anything, but X in dut_vector will only match X.
	assign tb_match = ( { out_ref } === ( { out_ref } ^ { out_dut } ^ { out_ref } ) );
	// Use explicit sensitivity list here. @(*) causes NetProc::nex_input() to be called when trying to compute
	// the sensitivity list of the @(strobe) process, which isn't implemented.
	always @(posedge clk, negedge clk) begin

		stats1.clocks++;
		if (!tb_match) begin
			if (stats1.errors == 0) stats1.errortime = $time;
			stats1.errors++;
		end
		if (out_ref !== ( out_ref ^ out_dut ^ out_ref ))
		begin if (stats1.errors_out == 0) stats1.errortime_out = $time;
			stats1.errors_out = stats1.errors_out+1'b1; end

	end


   // add timeout after 100K cycles
   initial begin
     #1000000
     $display("TIMEOUT");
     $finish();
   end


// DIAGNOSTIC OVERLAY ONLY. Original fixture preserved in separate original case.
integer cal_parent_edges=0, cal_port_edges=0;
wire [31:0] cal_checks = stats1.clocks;
always @(posedge clk or negedge clk) begin
 cal_parent_edges=cal_parent_edges+1;
 $display("CAL_PARENT t=%0t clk=%b checks_active=%0d match_active=%b",$time,clk,stats1.clocks,tb_match);
 $strobe("CAL_SETTLED t=%0t clk=%b checks=%0d match=%b",$time,clk,cal_checks,tb_match);
end
always @(posedge stim1.clk or negedge stim1.clk) begin
 cal_port_edges=cal_port_edges+1;
 $display("CAL_PORT t=%0t clk=%b",$time,stim1.clk);
end
initial $display("CAL_INIT t=%0t parent=%b port=%b",$time,clk,stim1.clk);
final $display("CAL_FINAL t=%0t parent_edges=%0d port_edges=%0d checks=%0d errors=%0d",$time,cal_parent_edges,cal_port_edges,stats1.clocks,stats1.errors);
always @(negedge clk or posedge clk) $strobe("CAL_VALUES t=%0t %b,%b,%b",$time,in,out_ref,out_dut);
endmodule

