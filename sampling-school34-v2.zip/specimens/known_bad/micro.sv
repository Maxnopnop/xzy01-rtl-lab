`timescale 1ps/1ps
module tb;
reg a=0;
wire good=~a;
wire bad=a;
integer i,checks=0,errors=0;
initial begin
 for(i=0;i<8;i=i+1) begin
  a=i%2;
  #1;
  checks=checks+1;
  if(good!==bad) errors=errors+1;
 end
 $display("Mismatches: %0d in %0d samples",errors,checks);
 $display("NEGATIVE_CONTROL expected_errors=8 expected_checks=8");
 $finish;
end
endmodule
