#!/bin/tcsh -f
source /usr/eelocal/synopsys/vcs-vx2025.06-sp1/.cshrc
if ($status != 0) exit 90
vcs -full64 -sverilog -top tb micro.sv -o simv -l compile.log
if ($status != 0) exit 92
./simv -l simulate.log
exit $status
