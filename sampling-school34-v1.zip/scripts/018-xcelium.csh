#!/bin/tcsh -f
source /usr/eelocal/cadence/xcelium2303hf/.cshrc
if ($status != 0) exit 90
xrun -64bit -sv -top tb dut.sv testbench.sv reference.sv -input run.tcl -l simulate.log
exit $status
